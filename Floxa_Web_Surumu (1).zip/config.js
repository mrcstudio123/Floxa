
const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
const SUPABASE_KEY = 'public-anon-key';
const supabase = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
