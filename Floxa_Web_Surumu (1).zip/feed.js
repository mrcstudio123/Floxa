
async function sharePost() {
  const content = document.getElementById('content').value;
  const user = await supabase.auth.getUser();
  const { error } = await supabase.from('posts').insert([{ content, user_id: user.data.user.id }]);
  if (error) return alert(error.message);
  document.getElementById('content').value = "";
  loadPosts();
}
async function loadPosts() {
  const { data, error } = await supabase.from('posts').select('*').order('id', { ascending: false });
  if (error) return alert(error.message);
  const container = document.getElementById('posts');
  container.innerHTML = "";
  data.forEach(post => {
    const div = document.createElement('div');
    div.className = 'post';
    div.textContent = post.content;
    container.appendChild(div);
  });
}
loadPosts();
